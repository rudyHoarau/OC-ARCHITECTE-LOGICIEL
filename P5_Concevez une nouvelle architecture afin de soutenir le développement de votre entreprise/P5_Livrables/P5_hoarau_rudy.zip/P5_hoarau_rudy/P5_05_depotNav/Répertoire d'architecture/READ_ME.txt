Contenue:
- Le métamodèle d'architecture
- La capacité d'architecture
- Le paysage architectural
- Les informations standard
- La bibliothèque de référence
- Le journal de gouvernance